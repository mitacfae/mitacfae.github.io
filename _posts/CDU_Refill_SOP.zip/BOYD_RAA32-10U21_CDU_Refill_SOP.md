---
title: "BOYD RAA32-10U21 CDU補液SOP"
layout: default
---

# BOYD RAA32-10U21 CDU補液SOP

## 使用設備清單

- G4520G6 * 1
- CDU * 1（型號：BOYD RAA32-10U21）
- 外部冷卻液儲水桶
- 補水管線（兩條，分為進水及排氣用）
- 抹布（用於集水桶孔徑密封與擦拭液體之用）
- 必要之個人防護裝備 (PPE)

## 注意事項

鑒於 CDU 後方 EXHAUST PORT 接口具備系統殘壓，為避免接口時發生氣體釋放或流體噴濺（Fluid Splashing），操作上須採取『先定位管路、後對接接口』之安全程序，以確保現場作業環境與人員安全。

執行系統補液作業時，考量流體排出之動能衝擊，補水管線存在跳脫容器之風險。為確保程序安全，於集水桶孔徑處採用抹布進行緊密充填。

將伺服器端與 CDU 建立完整的液冷迴路（Secondary Liquid Cooling Loop），以進行閉合循環。

## 操作步驟

1. CDU 電源接好並確認電力供應正常。

2. 執行外部補水作業時，移除 CDU 後側 EXHAUST PORT 黑色外蓋，並插上有快速接頭的出水管線（第一條水管），管線末端須全程置於外部冷卻液儲水槽中，以避免冷卻液體外漏。

   ![CDU 後側 EXHAUST PORT 接口位置](images/01-exhaust-port.jpg)

3. 移除 CDU 後側 COOLANT FILLING 黑色外蓋，並插上快速接頭的補水管線（第二條水管）建立補水管線，末端須全程置於外部冷卻液儲水槽中。

   ![CDU 後側 COOLANT FILLING 接口位置](images/02-coolant-filling.jpg)

4. 補液管線連接完成示意圖如下，此處 **INT** 接口定義為系統補水埠 (COOLANT FILLING)，**EXT** 接口定義為系統出水埠 (EXHAUST PORT)。系統運轉時，將自外部容器主動吸入冷卻液以進行系統充液。

   ![補液管線連接示意圖（INT＝補水埠，EXT＝出水埠）](images/03-loop-diagram.png)

5. 打開 Refill Pump。

   ![CDU 觸控面板：開啟 Refill Pump](images/04-refill-pump-on.jpg)

6. 確認後方 EXHAUST PORT 已將夾帶空氣完全排出。確認無氣泡後，將水管快速接頭脫開，無需完全拔除。

7. 補水泵會在完成充液後自行停止運作。（目視檢查夾帶空氣是否完全排出；若伺服器與 CDU 內部先前已預填冷卻液，此排氣與補水程序大約耗時 3 至 5 分鐘。）

8. 啟動 CDU。

9. 監測次級迴路（P2）的回水壓力（Return Pressure P2）。正常運作下壓力應維持在 130 kPa 以上。然而，開機初期運轉約 1 至 2 分鐘內，數值會出現向下掉的暫態波動；需等待系統迴路發展穩定、達到穩態（Steady State）後，再行紀錄與評估最終壓力值。

   ![CDU 觸控面板：系統狀態 Return Press P2](images/05-system-status-p2.jpg)

10. 若壓力仍未達標，則執行以下步驟：

    1. 關閉 CDU
    2. 啟動幫浦 (Refill Pump)
    3. 這時會再做補水的動作，補完水會自動停下來
    4. 回到步驟 8（Step 8）

11. 執行強制幫浦切換（Force Pump Switch），以驗證雙幫浦之備援切換機制（Pump Redundancy Crossover）。

    ![CDU 觸控面板：Force Pump Switch](images/06-force-pump-switch.jpg)

12. 關閉 CDU。

13. 拆卸 EXHAUST PORT 和 COOLANT FILLING 兩條補水水管，解除快速接頭之程序中時伴隨有微量殘液溢漏之風險。如有洩漏殘液，使用抹布擦乾。

14. 管線接頭脫開後，抬高管線利用重力將水管中殘液流回儲水槽，同時注意管線末端不脫離儲水槽，全程採雙人協同作業確保安全。

15. 收回補水管前，要確認管線已經滴乾，避免現場殘留液體。
